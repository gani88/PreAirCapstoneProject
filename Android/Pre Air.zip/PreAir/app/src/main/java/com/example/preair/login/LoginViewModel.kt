package com.example.preair.login

class LoginViewModel {
}